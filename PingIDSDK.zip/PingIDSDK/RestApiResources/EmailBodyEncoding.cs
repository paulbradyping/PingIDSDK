﻿using System.Runtime.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace PingIDSDK.RestApiResources
{
    [DataContract]
    [JsonConverter(typeof(StringEnumConverter))]
    public enum EmailBodyEncoding
    {
        // currently mail configurations can be created only with base64 encoding
        [EnumMember(Value = "RAW")]
        Raw,
        [EnumMember(Value = "BASE64")]
        Base64
    }
}