﻿using System.Runtime.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace PingIDSDK.RestApiResources
{
    [DataContract]
    [JsonConverter(typeof(StringEnumConverter))]
    public enum AuthenticationStatus
    {
        [EnumMember(Value = "OTP")]
        Otp,
        [EnumMember(Value = "REJECTED")]
        Rejected,
        [EnumMember(Value = "APPROVED")]
        Approved,
        [EnumMember(Value = "IN_PROGRESS")]
        InProgress,
        [EnumMember(Value = "TIMEOUT")]
        Timeout,
        [EnumMember(Value = "LOCKED")]
        Locked,
        [EnumMember(Value = "OTP_IS_BLOCKED")]
        OtpIsBlocked,
        [EnumMember(Value = "INVALID_OTP")]
        InvalidOtp,
        [EnumMember(Value = "CANCELED")]
        Canceled,
        [EnumMember(Value = "SELECT_DEVICE")]
        SelectDevice,
        [EnumMember(Value = "IGNORED_DEVICE")]
        IgnoredDevice,
        [EnumMember(Value = "BYPASSED_DEVICE")]
        BypassedDevice
    }
}