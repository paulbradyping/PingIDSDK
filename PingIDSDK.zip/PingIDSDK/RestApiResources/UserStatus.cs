﻿using System.Runtime.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;


namespace PingIDSDK.RestApiResources
{
    [DataContract]
    [JsonConverter(typeof(StringEnumConverter))]
    public enum UserStatus
    {
        [EnumMember(Value = "ACTIVE")]
        Active,
        [EnumMember(Value = "NOT_ACTIVE")]
        NotActive,
        [EnumMember(Value = "SUSPENDED")]
        Suspended,
        [EnumMember(Value = "BYPASS")]
        Bypass,
        [EnumMember(Value = "UNKNOWN")]
        Unknown
    }
}