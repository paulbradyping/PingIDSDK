﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;
using System.Text;


namespace PingIDSDK.RestApiResources
{
    public class RegistrationToken
    {
        [JsonProperty(PropertyName = "payload")]
        public string PayLoad { get; set; }

        [JsonProperty(PropertyName = "pairingKey")]
        public string PairingKey { get; set; }

        [JsonProperty(PropertyName = "ignoreValidation")]
        public bool IgnoreValidation { get; set; }

        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }
        
        public override string ToString()
        {
            var sb = new StringBuilder("RegToken {");
            sb.Append("payload='").Append(PayLoad);
            sb.Append(", ignoreValidation=").Append(IgnoreValidation);
            sb.Append(",pairingKey=").Append(PairingKey);
            sb.Append(", id=").Append(Id);
            sb.Append('}');

            return sb.ToString();
        }
    }
}