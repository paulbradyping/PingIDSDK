﻿using System.Text;
using Newtonsoft.Json;

namespace PingIDSDK.RestApiResources
{
    public class EmailConfiguration
    {
        [JsonProperty(PropertyName = "fromAddress")]
        public string FromAddress { get; set; }

        [JsonProperty(PropertyName = "emailSubject")]
        public string EmailSubject { get; set; }

        [JsonProperty(PropertyName = "emailBody")]
        public string EmailBody { get; set; }

        [JsonProperty(PropertyName = "replyToAddress")]
        public string ReplyToAddress { get; set; }

        [JsonProperty(PropertyName = "characterSet")]
        public string CharacterSet { get; set; }

        [JsonProperty(PropertyName = "locale")]
        public string Locale { get; set; }

        [JsonProperty(PropertyName = "type")]
        public string Type { get; set; }

        [JsonProperty(PropertyName = "emailBodyEncoding")]
        public EmailBodyEncoding EmailBodyEncoding { get; set; }

        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }

        public override string ToString()
        {
            var sb = new StringBuilder("EmailConfiguration {");
            sb.Append("fromAddress='").Append(FromAddress).Append('\'');
            sb.Append(", emailSubject='").Append(EmailSubject).Append('\'');
            sb.Append(", emailBody='").Append(EmailBody).Append('\'');
            sb.Append(", replyToAddress='").Append(ReplyToAddress).Append('\'');
            sb.Append(", characterSet='").Append(CharacterSet).Append('\'');
            sb.Append(", locale='").Append(Locale).Append('\'');
            sb.Append(", type='").Append(Type).Append('\'');
            sb.Append(", emailBodyEncoding='").Append(EmailBodyEncoding).Append('\'');
            sb.Append(", id='").Append(Id).Append('\'');
            sb.Append('}');
            return sb.ToString();
        }
    }
}