﻿using System;
using System.Text;
using Newtonsoft.Json;
using PingIDSDK.PingIDSDKHelper.JsonConverter;


namespace PingIDSDK.RestApiResources
{
    public class Device
    {
        [JsonProperty(PropertyName = "deviceType")]
        public string DeviceType { get; set; }

        [JsonProperty(PropertyName = "Id")]
        public string Id { get; set; }

        [JsonProperty(PropertyName = "deviceName")]
        public string DeviceName { get; set; }

        [JsonProperty(PropertyName = "deviceNickname")]
        public string DeviceNickname { get; set; }

        [JsonProperty(PropertyName = "deviceFingerprint")]
        public string DeviceFingerprint { get; set; }

        [JsonProperty(PropertyName = "deviceRole")]
        public string DeviceRole { get; set; }

        [JsonProperty(PropertyName = "enrollmentTime")]
        [JsonConverter(typeof(DateTimeToEpochJsonConverter))]
        public DateTime? EnrollmentTime { get; set; }

        [JsonProperty(PropertyName = "applicationId")]
        public string ApplicationId { get; set; }

        [JsonProperty(PropertyName = "bypassExpiration")]
        [JsonConverter(typeof(DateTimeToEpochJsonConverter))]
        public DateTime? BypassExpiration { get; set; }

        [JsonProperty(PropertyName = "bypassed")]
        public bool Bypassed { get; set; }


        public override string ToString()
        {
            var sb = new StringBuilder("Device{");
            sb.Append("deviceType='").Append(DeviceType).Append('\'');
            sb.Append(", id='").Append(Id).Append('\'');
            sb.Append(", applicationId='").Append(ApplicationId).Append('\'');
            sb.Append(", deviceName='").Append(DeviceName).Append('\'');
            sb.Append(", deviceRole='").Append(DeviceRole).Append('\'');
            sb.Append(", enrollmentTime='").Append(EnrollmentTime).Append('\'');
            sb.Append(", bypassExpiration='").Append(BypassExpiration).Append('\'');
            sb.Append('}');
            return sb.ToString();
        }
    }
}