﻿using System.Runtime.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace PingIDSDK.RestApiResources
{
    [DataContract]
    [JsonConverter(typeof(StringEnumConverter))]
    public enum AuthenticationLevel
    {
        [EnumMember(Value = "NONE")]
        None,
        [EnumMember(Value = "MOBILE_PAYLOAD")]
        MobilePayload,
        [EnumMember(Value = "OTP")]
        Otp,
        [EnumMember(Value = "PUSH")]
        Push
    }
}