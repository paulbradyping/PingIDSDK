﻿using System.Text;
using Newtonsoft.Json;

namespace PingIDSDK.RestApiResources
{
    public class FinalizePairing
    {
        [JsonProperty(PropertyName = "otp")]
        public string Otp { get; set; }

        [JsonProperty(PropertyName = "deviceNickname")]
        public string DeviceNickname { get; set; }

        public override string ToString()
        {
            var sb = new StringBuilder("FinalizePairing {");
            sb.Append("otp='").Append(Otp);
            sb.Append(", deviceNickname='").Append(DeviceNickname);
            sb.Append('}');
            return sb.ToString();
        }
    }
}