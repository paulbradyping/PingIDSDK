﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;


namespace PingIDSDK.RestApiResources
{
    public class VoicePairing
    {
        [JsonProperty(PropertyName = "phoneNumber")]
        public string PhoneNumber { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string Message { get; set; }

        [JsonProperty(PropertyName = "local")]
        public string Local { get; set; }

        [JsonProperty(PropertyName = "automaticPairing")]
        public bool AutomaticPairing { get; set; }

        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }

        [JsonProperty(PropertyName = "voice")]
            public string Voice { get; set; }

        public override string ToString()
        {
            var sb = new StringBuilder("Pairing {");
            sb.Append("phoneNumber='").Append(PhoneNumber);
            sb.Append(", message='").Append(Message);
            sb.Append(", local='").Append(Local);
            sb.Append(", automaticPairing=").Append(AutomaticPairing);
            sb.Append(", id=").Append(Id);
            sb.Append(", voice").Append(Voice);
            sb.Append('}');

            return sb.ToString();
        }

    }
}