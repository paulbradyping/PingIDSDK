﻿using System.Text;
using Newtonsoft.Json;

namespace PingIDSDK.RestApiResources
{
    public class SmsOfflinePairing
    {
        [JsonProperty(PropertyName = "phoneNumber")]
        public string PhoneNumber { get; set; }

        [JsonProperty(PropertyName = "message")]
        public string Message { get; set; }

        [JsonProperty(PropertyName = "sender")]
        public string Sender { get; set; }

        [JsonProperty(PropertyName = "automaticPairing")]
        public bool AutomaticPairing { get; set; }

        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }

        public override string ToString()
        {
            var sb = new StringBuilder("Pairing {");
            sb.Append("phoneNumber='").Append(PhoneNumber);
            sb.Append(", message='").Append(Message);
            sb.Append(", sender='").Append(Sender);
            sb.Append(", automaticPairing=").Append(PingIdProperties.autopair);
            sb.Append(", id=").Append(Id);
            sb.Append('}');

            return sb.ToString();
        }
    }
}