﻿using System;
using System.Text;
using Newtonsoft.Json;

namespace PingIDSDK.RestApiResources
{
    public class NativeMobileAppPairing
    {
        [JsonProperty(PropertyName = "CreatedPairingKey")]
        public string PairingData { get; set; }

    }
}