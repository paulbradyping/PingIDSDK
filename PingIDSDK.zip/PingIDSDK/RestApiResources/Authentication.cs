﻿using System.Text;
using Newtonsoft.Json;

namespace PingIDSDK.RestApiResources
{
    public class Authentication
    {
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }

        [JsonProperty(PropertyName = "deviceId")]
        public string DeviceId { get; set; }

        [JsonProperty(PropertyName = "authenticationType")]
        public AuthenticationType AuthenticationType { get; set; }

        [JsonProperty(PropertyName = "ipAddress")]
        public string IpAddress { get; set; }

        [JsonProperty(PropertyName = "userAgent")]
        public string UserAgent { get; set; }

        [JsonProperty(PropertyName = "offlineOTP")]
        public string OfflineOTP { get; set; }

        [JsonProperty(PropertyName = "status")]
        public AuthenticationStatus Status { get; set; }

        [JsonProperty(PropertyName = "device")]
        public Device Device { get; set; }

        [JsonProperty(PropertyName = "accessingDevice")]
        public Device AccessingDevice { get; set; }

        [JsonProperty(PropertyName = "requiredLevel")]
        public AuthenticationLevel RequiredLevel { get; set; }

        [JsonProperty(PropertyName = "level")]
        public AuthenticationLevel Level { get; set; }

        [JsonProperty(PropertyName = "pushMessageTitle")]
        public string PushMessageTitle { get; set; }

        [JsonProperty(PropertyName = "pushMessageBody")]
        public string PushMessageBody { get; set; }

        [JsonProperty(PropertyName = "clientContext")]
        public string ClientContext { get; set; }

        [JsonProperty(PropertyName = "smsMessage")]
        public string SmsMessage { get; set; }

        [JsonProperty(PropertyName = "smsSender")]
        public string SmsSender { get; set; }

        [JsonProperty(PropertyName = "locale")]
        public string Locale { get; set; }

        [JsonProperty(PropertyName = "emailConfigurationType")]
        public string EmailConfigurationType { get; set; }

        [JsonProperty(PropertyName = "voiceMessage")]
        public string voiceMessage { get; set; }

        public override string ToString()
        {
            var sb = new StringBuilder("Authentication {");
            sb.Append("id='").Append(Id);
            sb.Append(", deviceId='").Append(DeviceId);
            sb.Append(", ipAddress='").Append(IpAddress);
            sb.Append(", userAgent=").Append(UserAgent);
            sb.Append(", authenticationType=").Append(AuthenticationType);
            sb.Append(", status=").Append(Status);
            sb.Append(", accessingDevice=").Append(AccessingDevice);
            sb.Append(", authenticationDevice=").Append(Device);
            sb.Append(", requiredLevel=").Append(RequiredLevel);
            sb.Append(", level=").Append(Level);
            sb.Append(", smsMessage=").Append(SmsMessage);
            sb.Append(", smsSender=").Append(SmsSender);
            sb.Append(", voiceMessage=").Append(voiceMessage);
            sb.Append(", locale=").Append(Locale);
            sb.Append(", emailConfigurationType=").Append(EmailConfigurationType);
            sb.Append('}');

            return sb.ToString();
        }
    }
}