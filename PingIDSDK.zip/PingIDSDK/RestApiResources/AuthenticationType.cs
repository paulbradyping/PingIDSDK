﻿using System.Runtime.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace PingIDSDK.RestApiResources
{
    [DataContract]
    [JsonConverter(typeof(StringEnumConverter))]
    public enum AuthenticationType
    {
        [EnumMember(Value = "AUTHENTICATE")]
        Authenticate,
        [EnumMember(Value = "FINGERPRINT_PERMISSIVE")]
        FingerprintPermissive,
        [EnumMember(Value = "FINGERPRINT_RESTRICTIVE")]
        FingerprintRestrictive,
        [EnumMember(Value = "FINGERPRINT_HARD_RESTRICTIVE")]
        FingerprintHardRestrictive,
        [EnumMember(Value = "OTP")]
        Otp,
        [EnumMember(Value = "SWIPE")]
        Swipe,
        [EnumMember(Value = "SILENT_AUTHENTICATE")]
        SilentAuthenticate,
        [EnumMember(Value = "FINGERPRINT_RESTRICTEIVE_HARD_NO_FALLBACK")]
        FingerprintRestricteiveHardNoFallback
    }
}