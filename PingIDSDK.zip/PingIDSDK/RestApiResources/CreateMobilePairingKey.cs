﻿using System.Text;
using Newtonsoft.Json;


namespace PingIDSDK.RestApiResources
{
    public class CreateMobilePairingKey
    {
        [JsonProperty(PropertyName = "pairingData")]
        public string PairingData { get; set; }
        
        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }

        public override string ToString()
        {
            var sb = new StringBuilder("Pairing {");
            sb.Append("pairingData='").Append(PairingData);
            sb.Append(", id=").Append(Id);
            sb.Append('}');

            return sb.ToString();
        }
    }
}