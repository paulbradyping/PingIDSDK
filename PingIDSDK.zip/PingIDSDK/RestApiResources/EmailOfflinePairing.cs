﻿using System.Text;
using Newtonsoft.Json;

namespace PingIDSDK.RestApiResources
{
    public class EmailOfflinePairing
    {
        [JsonProperty(PropertyName = "locale")]
        public string Lcoale { get; set; }

        [JsonProperty(PropertyName = "type")]
        public string Type { get; set; }

        [JsonProperty(PropertyName = "recipient")]
        public string Recipient { get; set; }

        [JsonProperty(PropertyName = "automaticPairing")]
        public bool AutomaticPairing { get; set; }

        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }

        public override string ToString()
        {
            var sb = new StringBuilder("Pairing {");
            sb.Append("locale='").Append(Lcoale);
            sb.Append(", type='").Append(Type);
            sb.Append(", recipient='").Append(Recipient);
            sb.Append(", automaticPairing=").Append(PingIdProperties.autopair);
            sb.Append(", id=").Append(Id);
            sb.Append('}');

            return sb.ToString();
        }
    }
}