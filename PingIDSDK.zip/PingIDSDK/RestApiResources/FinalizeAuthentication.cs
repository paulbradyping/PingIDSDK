﻿using System.Text;
using Newtonsoft.Json;

namespace PingIDSDK.RestApiResources
{
    public class FinalizeAuthentication
    {
        [JsonProperty(PropertyName = "payload")]
        public string Payload { get; set; }

        [JsonProperty(PropertyName = "otp")]
        public string Otp { get; set; }

        public override string ToString()
        {
            var sb = new StringBuilder("FinalizeAuthentication {");
            sb.Append("otp='").Append(Otp);
            sb.Append(", payload='").Append(Payload);
            sb.Append('}');
            return sb.ToString();
        }
    }
}