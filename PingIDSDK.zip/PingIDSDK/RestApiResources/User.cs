﻿using System;
using System.Text;
using Newtonsoft.Json;
using PingIDSDK.PingIDSDKHelper.JsonConverter;


namespace PingIDSDK.RestApiResources
{
    public class User
    {
        [JsonProperty(PropertyName = "username")]
        public string Username { get; set; }

        [JsonProperty(PropertyName = "firstName")]
        public string FirstName { get; set; }

        [JsonProperty(PropertyName = "lastName")]
        public string LastName { get; set; }

        [JsonProperty(PropertyName = "status")]
        public UserStatus? Status { get; set; }

        [JsonProperty(PropertyName = "isUserInBypass")]
        public bool IsUserInBypass { get; set; }

        [JsonProperty(PropertyName = "lastLogin")]
        [JsonConverter(typeof(DateTimeToEpochJsonConverter))]
        public DateTime? LastLogin { get; set; }

        [JsonProperty(PropertyName = "bypassExpiration")]
        [JsonConverter(typeof(DateTimeToEpochJsonConverter))]
        public DateTime? BypassExpiration { get; set; }


        public override string ToString()
        {
            var sb = new StringBuilder("User{");
            sb.Append("username='").Append(Username).Append('\'');
            sb.Append(", firstName='").Append(FirstName).Append('\'');
            sb.Append(", lastName='").Append(LastName).Append('\'');
            sb.Append(", status=").Append(Status);
            sb.Append(", isUserInBypass=").Append(IsUserInBypass);
            sb.Append(", lastLogin=").Append(LastLogin);
            sb.Append(", bypassExpiration=").Append(BypassExpiration);
            sb.Append('}');
            return sb.ToString();
        }
    }
}