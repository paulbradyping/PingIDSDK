﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using PingIDSDK.ErrorHandling;



namespace PingIDSDK.PingIDSDKHelper
{
    public class PingIDSdkApiUtility
    {
        private const string PingIDAuthHeader = "X-PINGID-Singature";
        private readonly string _accountId;
        private readonly string _apiKey;
        private readonly string _token;

        public PingIDSdkApiUtility(string accountId, string apiKey, string token)
        {
            _accountId = accountId;
            _apiKey = apiKey;
            _token = token;
        }

        public T GetRequest<T>(string apiEndpoint)
        {
            var nameOfType = typeof(T).Name;
            var jwt = BuildHeaders(apiEndpoint, "GET", null);
            var resp = HttpGet(apiEndpoint, jwt);

            if (resp == null)
            {
                return default(T);
            }

            string desresponse = JsonConvert.DeserializeObject<T>(resp).ToString();

            PingIdProperties.Responsedata = resp;


            return JsonConvert.DeserializeObject<T>(resp);
        }

        public void DeleteRequest(string apiEndpoint)
        {
            var jwt = BuildHeaders(apiEndpoint, "DELETE", null);
            HttpDelete(apiEndpoint, jwt);

            
        }

        public List<T> GetCollectionRequest<T>(string apiEndpoint, string collectionKey)
        {
            var nameOfType = typeof(T).Name;
            var jwt = BuildHeaders(apiEndpoint, "GET", null);
            var resp = HttpGet(apiEndpoint, jwt);

            if (resp == null)
            {
                return null;
            }
            var values = JsonConvert.DeserializeObject<Dictionary<string, List<T>>>(resp);
            return values[collectionKey];
        }

        public T PostRequest<T>(string apiEndpoint, object entity)
        {
            var nameOfType = typeof(T).Name;
            var jwt = BuildHeaders(apiEndpoint, "POST", entity);
            var resp = HttpPost(nameOfType, apiEndpoint, jwt, entity);

            return JsonConvert.DeserializeObject<T>(resp);
        }

        public T PutRequest<T>(string apiEndpoint, object entity)
        {
            var nameOfType = typeof(T).Name;
            var jwt = BuildHeaders(apiEndpoint, "PUT", entity);
            var resp = HttpPut(nameOfType, apiEndpoint, jwt, entity);

            return JsonConvert.DeserializeObject<T>(resp);
        }

        public void PutRequestNoContent<T>(string apiEndpoint, object entity)
        {
            var nameOfType = typeof(T).Name;
            var jwt = BuildHeaders(apiEndpoint, "PUT", entity);
            HttpPutNoContent(apiEndpoint, jwt, entity);
        }

        private string BuildHeaders(string uri, string httpRequestMethod, object entity)
        {
            //createAuthorizationHeader
            //In this case there is no query params
            var canonicalStr = GetCanonicalStr(uri, httpRequestMethod, Constants.SdkHost, "", entity);
            var authorization = CalculateSha256(canonicalStr);
            //buildHeaders
            var authHeader = JwtSign(authorization);

            var authorizationHedaerValue = new StringBuilder();
            authorizationHedaerValue.Append("PINGID-HMAC=");
            var stringAuthHeader = Encoding.UTF8.GetString(authHeader, 0, authHeader.Length);
            authorizationHedaerValue.Append(stringAuthHeader);

            return authorizationHedaerValue.ToString();
        }

        private string GetCanonicalStr(string uri, string method, string host, string queryParams, object entity)
        {
            if (uri.Contains("?expand=seendevices,devices"))
            {
                //uri = "https://sdk.pingid.com/pingid/v1/accounts/6438823d-671c-42e7-9b1e-8960494ef5e4/applications/e7be90e2-9f44-4d83-8d55-2e1f1146c9bc/users/pncsmstest4?ex";

                uri = uri.Substring(0, uri.IndexOf("?"));

                queryParams = "expand=seendevices,devices";
                //queryParams = "expand=seendevices";
                //queryParams = "expand=account,devices";
            }
            var hashedPayload = CalculateSha256(entity ?? "");


            //"https://sdk.pingid.com/pingid/v1/accounts/6438823d-671c-42e7-9b1e-8960494ef5e4/applications/e7be90e2-9f44-4d83-8d55-2e1f1146c9bc/users/pncsmstest4?expand=seendevices,devices"

            var path = uri.Replace("https://" + Constants.SdkHost, "");
            var sb = new StringBuilder("");
            sb.Append(method).Append(":");
            sb.Append(host).Append(":");
            sb.Append(path).Append(":");

          


            sb.Append(queryParams).Append(queryParams.Equals("") ? "" : ":");
            sb.Append(hashedPayload).Append(":");
            //if (sb.ToString().Contains(":?"))
            //{
            //    sb.Replace(":?", "?");
            //}

            return sb.ToString();
        }

        private byte[] JwtSign(string data)
        {
            var jwtHeader = new Dictionary<string, object>
            {
                {"alg", "HS256"},
                {"typ", "JWT"},
                {"account_id", _accountId},
                {"token", _token}
            };
            var expiresAsIso = GetExpirationDate();
            jwtHeader.Add("expires", expiresAsIso);
            var requestId = Guid.NewGuid().ToString();
            jwtHeader.Add("X-Request-ID", requestId);
            jwtHeader.Add("jwt_version", "v4");

            var headerSerialized = DictionaryToJsonstring(jwtHeader);
            var headerEncoded = Base64UrlEncodestring(headerSerialized);

            var jwtPayLoad = new Dictionary<string, object>
            {
                {"data", data}
            };
            var payLoadSerialized = DictionaryToJsonstring(jwtPayLoad);
            var payLoadEncoded = Base64UrlEncodestring(payLoadSerialized);

            var signedComponents = string.Join(".", headerEncoded, payLoadEncoded);

            var signingKey = new HMACSHA256(Base64UrlDecodestring(_apiKey));

            var signatureBytes = signingKey.ComputeHash(Encoding.UTF8.GetBytes(signedComponents));
            var signatureEncoded = Base64UrlEncodestring(signatureBytes);

            var serial = string.Join(".", signedComponents, signatureEncoded);

            var serialByte = Encoding.UTF8.GetBytes(serial);
            return serialByte;
        }

        private string GetExpirationDate()
        {
            var now = DateTime.UtcNow;
            var expires = now.AddMinutes(5);
            return expires.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'");
        }

        private string HttpGet(string uri, string jwt)
        {
            var webRequest = WebRequest.Create(uri);

            var webHeader = new WebHeaderCollection
                {
                    {"Authorization", jwt}
                };
            webRequest.Headers = webHeader;
            WebResponse webResponse;

            try
            {
                webResponse = webRequest.GetResponse();
            }
            catch (WebException we)
            {
                webResponse = we.Response as HttpWebResponse;
                if (webResponse == null)
                {
                    throw;
                }
            }

            string response = null;
            var responseStream = webResponse.GetResponseStream();
            if (responseStream != null)
            {
                var sr = new StreamReader(responseStream);
                response = sr.ReadToEnd().Trim();
            }
            //Verify the response
            VerifyResponse(webResponse, response);
            var myHttpWebResponse = (HttpWebResponse)webResponse;

            if (myHttpWebResponse.StatusCode.Equals(HttpStatusCode.NotFound))
            {
                return null;
            }
            //verify the status
            VerifyStatus(response, (int)myHttpWebResponse.StatusCode, (int)HttpStatusCode.OK);

            return response;

        }

        private string HttpPost(string nameOfType, string uri, string jwt, object entity)
        {
            var webRequest = (HttpWebRequest)WebRequest.Create(uri);

            var webHeader = new WebHeaderCollection
            {
                {"Authorization", jwt}
            };
            webRequest.Headers = webHeader;
            webRequest.ContentType = "application/json";
            webRequest.Method = "POST";

            var jsonPayload = JsonConvert.SerializeObject(entity);

            using (var streamWriter = new StreamWriter(webRequest.GetRequestStream()))
            {
                streamWriter.Write(jsonPayload);
                streamWriter.Flush();
                streamWriter.Close();
            }
            WebResponse webResponse;

            try
            {
                webResponse = webRequest.GetResponse();
            }
            catch (WebException we)
            {
                webResponse = we.Response as HttpWebResponse;

                if (webResponse == null)
                {
                    throw;
                }
            }

            string response = null;
            var responseStream = webResponse.GetResponseStream();
            if (responseStream != null)
            {
                var getResponse = new StreamReader(responseStream);
                response = getResponse.ReadToEnd().Trim();
            }

            var myHttpWebResponse = (HttpWebResponse)webResponse;
            //verify the status
            try
            {
                VerifyStatus(response, (int)myHttpWebResponse.StatusCode, (int)HttpStatusCode.Created);
            }
            catch (PingIDSdkException pingIDSdkEx)
            {
                if (IsEntityNotFoundError(nameOfType, pingIDSdkEx))
                {
                    return null;
                }
                throw;
            }

            //Verify the response
            VerifyResponse(webResponse, response);

            return response;
        }

        private string HttpPut(string nameOfType, string uri, string jwt, object entity)
        {
            var webRequest = (HttpWebRequest)WebRequest.Create(uri);

            var webHeader = new WebHeaderCollection
            {
                {"Authorization", jwt}
            };
            webRequest.Headers = webHeader;
            webRequest.ContentType = "application/json";
            webRequest.Method = "PUT";

            var jsonPayload = JsonConvert.SerializeObject(entity);

            using (var streamWriter = new StreamWriter(webRequest.GetRequestStream()))
            {
                streamWriter.Write(jsonPayload);
                streamWriter.Flush();
                streamWriter.Close();
            }

            WebResponse webResponse;

            try
            {
                webResponse = webRequest.GetResponse();
            }
            catch (WebException we)
            {
                webResponse = we.Response as HttpWebResponse;
                if (webResponse == null)
                {
                    throw;
                }
            }

            string response = null;
            var responseStream = webResponse.GetResponseStream();
            if (responseStream != null)
            {
                var getResponse = new StreamReader(responseStream);
                response = getResponse.ReadToEnd().Trim();
            }
            var myHttpWebResponse = (HttpWebResponse)webResponse;

            //verify the status
            try
            {
                VerifyStatus(response, (int)myHttpWebResponse.StatusCode, (int)HttpStatusCode.OK);
            }
            catch (PingIDSdkException pingIDSdkEx)
            {
                if (IsEntityNotFoundError(nameOfType, pingIDSdkEx))
                {
                    return null;
                }
                throw;
            }

            //Verify the response
            VerifyResponse(webResponse, response);

            return response;
        }

        private void HttpPutNoContent(string uri, string jwt, object entity)
        {
            var webRequest = (HttpWebRequest)WebRequest.Create(uri);

            var webHeader = new WebHeaderCollection
            {
                {"Authorization", jwt}
            };
            webRequest.Headers = webHeader;
            webRequest.ContentType = "application/json";
            webRequest.Method = "PUT";

            var jsonPayload = JsonConvert.SerializeObject(entity);
            using (var streamWriter = new StreamWriter(webRequest.GetRequestStream()))
            {
                streamWriter.Write(jsonPayload);
                streamWriter.Flush();
                streamWriter.Close();
            }
            WebResponse webResponse;
            try
            {
                webResponse = webRequest.GetResponse();
            }
            catch (WebException we)
            {
                webResponse = we.Response as HttpWebResponse;
                if (webResponse == null)
                {
                    throw;
                }
            }
            string response = null;
            var responseStream = webResponse.GetResponseStream();
            if (responseStream != null)
            {
                var getResponse = new StreamReader(responseStream);
                response = getResponse.ReadToEnd().Trim();
            }

            //verify the status
            var myHttpWebResponse = (HttpWebResponse)webResponse;
            VerifyStatus(response, (int)myHttpWebResponse.StatusCode, (int)HttpStatusCode.NoContent);

            //Verify the response
            VerifyResponse(webResponse, response);
        }

        private void HttpDelete(string uri, string jwt)
        {
            var webRequest = (HttpWebRequest)WebRequest.Create(uri);

            var webHeader = new WebHeaderCollection
            {
                {"Authorization", jwt}
            };
            webRequest.Headers = webHeader;
            webRequest.ContentType = "application/json";
            webRequest.Method = "DELETE";
            WebResponse webResponse;
            try
            {
                webResponse = webRequest.GetResponse();
            }
            catch (WebException we)
            {
                webResponse = we.Response as HttpWebResponse;
                if (webResponse == null)
                {
                    throw;
                }
            }
            string response = null;
            var responseStream = webResponse.GetResponseStream();
            if (responseStream != null)
            {
                var getResponse = new StreamReader(responseStream);
                response = getResponse.ReadToEnd().Trim();
            }
            //verify the status
            var myHttpWebResponse = (HttpWebResponse)webResponse;
            VerifyStatus(response, (int)myHttpWebResponse.StatusCode, (int)HttpStatusCode.NoContent);

            //Verify the response
            VerifyResponse(webResponse, response);
        }

        private void VerifyResponse(WebResponse clientResponse, string responseBody)
        {
            var tokenHeader = RetrieveTokenFromHeaders(clientResponse);
            string responseSignedPayload;
            try
            {
                responseSignedPayload = CalculateSha256(responseBody);
            }
            catch (Exception e)
            {
                throw new Exception("Failed create response payload", e);
            }

            var jwtPayload = VerifyJwt(tokenHeader);

            if (!responseSignedPayload.Equals(jwtPayload))
            {
                throw new Exception("Request and header payload are not equal");
            }
        }

        private static string RetrieveTokenFromHeaders(WebResponse clientResponse)
        {
            var tokenHeaderExists = clientResponse?.Headers?.GetValues(PingIDAuthHeader) != null && clientResponse.Headers.GetValues(PingIDAuthHeader).Length == 1;
            if (tokenHeaderExists)
            {
                return clientResponse.Headers.GetValues(PingIDAuthHeader).GetValue(0).ToString();
            }
            throw new Exception("invalid server response");
        }

        private void VerifyStatus(string responseEntity, int actualStatus, int expectedStatus)
        {
            if (actualStatus == expectedStatus)
            {
                return;
            }

            if (responseEntity == null)
            {
                throw new PingIDSdkException(actualStatus, "PingID SDK failed to handle the request");
            }

            RestAPIError error = null;
            try
            {
                error = JsonConvert.DeserializeObject<RestAPIError>(responseEntity);
            }
            catch (Exception e)
            {
                throw new PingIDSdkException(actualStatus,
                    string.Format("PingID SDK not properly configured {0}", e.Message));
            }

            if (error != null)
            {
                throw new PingIDSdkException(actualStatus, error);
            }

            throw new PingIDSdkException(actualStatus, "PingID SDK not properly configured. null error");
        }

        private bool IsEntityNotFoundError(string resourceName, PingIDSdkException pingIDSdkEx)
        {
            if (pingIDSdkEx.GetPingIDSdkResponseStatus() != (int)HttpStatusCode.NotFound)
            {
                return false;
            }

            var error = pingIDSdkEx.GetPingIDSdkError();

            if (error == null || error.Target == null || !error.Target.Equals(resourceName.ToLower()))
            {
                return false;
            }

            return true;
        }

        private string VerifyJwt(string authorizationHeader)
        {
            if (authorizationHeader == null || authorizationHeader.Equals(""))
            {
                throw new Exception("Header cannot be null/empty");
            }
            var data = authorizationHeader.Split('.')[1];
            var dataJwt = Base64UrlDecodestring(data);
            var jwtStr = Encoding.UTF8.GetString(dataJwt, 0, dataJwt.Length);
            var obj1 = JsonConvert.DeserializeObject<JObject>(jwtStr);
            jwtStr = (string)obj1["data"];

            return jwtStr;
        }

        private string CalculateSha256(object data)
        {
            if (data == null)
            {
                data = "";
            }

            var objStr = GetObjStr(data);
            var hashBytes = Encoding.UTF8.GetBytes(objStr);
            var sha256 = SHA256.Create();
            var cryptPassword = sha256.ComputeHash(hashBytes);
            var hexCode = ToHex(cryptPassword);

            return hexCode;
        }

        private string GetObjStr(object data)
        {
            string dataString = "";

            string objStr;

            //  if (data is string != data)

            //            string objStr;
            if (data is string)
            {
                dataString = data.ToString();

                return dataString;
            }

            //if (data.ToString() != dataString)
            //{
            //    return dataString;
            //}

            try
            {
                objStr = JsonConvert.SerializeObject(data);
            }
            catch
            {
                throw new Exception();
            }

            return objStr;
        }

        private string Base64UrlEncodestring(string rawstring)
        {
            return Base64UrlEncodestring(Encoding.UTF8.GetBytes(rawstring));
        }

        private string Base64UrlEncodestring(byte[] rawBytes)
        {
            var encodedstring = Convert.ToBase64String(rawBytes);

            encodedstring = encodedstring.Replace('+', '-');
            encodedstring = encodedstring.Replace('/', '_');
            encodedstring = encodedstring.TrimEnd('=');

            return encodedstring;
        }

        private byte[] Base64UrlDecodestring(string encodedstring)
        {
            encodedstring = encodedstring.Replace('-', '+');
            encodedstring = encodedstring.Replace('_', '/');
            encodedstring = encodedstring.Replace("\\", "");
            encodedstring = encodedstring.PadRight(encodedstring.Length + (4 - encodedstring.Length % 4) % 4, '=');

            return Convert.FromBase64String(encodedstring);
        }

        private string DictionaryToJsonstring(Dictionary<string, object> dictionary)
        {
            return JsonConvert.SerializeObject(dictionary);
        }

        private string ToHex(byte[] bytes)
        {
            return BitConverter.ToString(bytes).Replace("-", string.Empty).ToLower();
        }
    }
}