﻿using System;
using System.Collections.Generic;
using System.IO;
using PingIDSDK.RestApiResources;


namespace PingIDSDK.PingIDSDKHelper
{
    public static class CommonRequests
    {
        // 0 = accountID
        // 1 = applications
        //2 = app ID
        //3 = userid

        private const string AuthenticationBasePathTemplate = "{0}/{1}/applications/{2}/users/{3}/authentications";
        private const string FinalizeAuthenticationPathTemplate = AuthenticationBasePathTemplate + "/{4}/otp";

        private const string SmsPairingBasePathTemplate = "{0}/{1}/applications/{2}/users/{3}/smspairings";
        private const string FinalizeSmsPairingPathTemplate = SmsPairingBasePathTemplate + "/{4}/otp";

        private const string EmailPairingBasePathTemplate = "{0}/{1}/applications/{2}/users/{3}/emailpairings";
        private const string FinalizeEmailPairingPathTemplate = EmailPairingBasePathTemplate + "/{4}/otp";

        private const string UsersByAccountBasePathTemplate = "{0}/{1}/users";

        private const string DevicesByApplicationBasePathTemplate = "{0}/{1}/applications/{2}/users/{3}/devices";

        private const string DeviceBasePathTemplate = "{0}/{1}/users/{2}/devices";
        private const string DevicePathByIDTemplate = DeviceBasePathTemplate + "/{3}";

        private const string UsersByAppBasePathTemplate = "{0}/{1}/applications/{2}/users";
        private const string UsersByAppAndIDPathTemplate = UsersByAppBasePathTemplate + "/{3}";
        private const string UsersExpanded = UsersByAppAndIDPathTemplate+ "?expand=seendevices,devices";

        private const string EmailConfigurationsBasePathTemplate = "{0}/{1}/applications/{2}/emailconfigurations";
        private const string EmailConfigurationByTypeAdeLocalePathTemplate = EmailConfigurationsBasePathTemplate + "?type={3}&locale={4}";
        private const string EmailConfigurationByIDPathTemplate = EmailConfigurationsBasePathTemplate + "/{3}";

        private const string VoicePairingBasePathTemplate = "{0}/{1}/applications/{2}/users/{3}/voicepairings";
        private const string FinalizeVoicePairingBasePathTemplate = VoicePairingBasePathTemplate + "/{4}/otp";
        private const string VoicePairStatustemplate = "{0}/{1}/applications/{2}/users/";

        private const string PairMobileNativeTemplate = "{0}/{1}/applications/{2}/pairingkeys";

        private const string AuthAPItemplate = "{0}/{1}/applications/{2}/users/";

        private const string RegistrationTokenBasePath = "{0}/{1}/applications/{2}/users/{3}/registrationtokens";

        

        ///accounts/{accountId}/applications/{applicationId}/users/{username}/voicepairings/{pairingId}

        //
        //'https://sdk.pingid.com/pingid/v1/accounts/e17f898d-3577-490d-baa7-64ceecf6b8a5/applications/49b9ed37-31ce-488f-9c44-1fe1ed95f756/users/john.galt?expand=seendevices,devices'
        //

        /*
         * 
//         * 
//         * "self": {
//"href": "https://sdk.pingid.com/pingid/v1/accounts/e17f898d-3577-490d-baa7-64ceecf6b8a5/applications/49b9ed37-31ce-488f-9c44-1fe1ed95f756/pairingkeys/349666846915"
//}
//         * 
//         */

        private static readonly string AccountId = PingIdProperties.accountId;
        private static readonly string ApiKey = PingIdProperties.apiKey;
        private static readonly string Token = PingIdProperties.token;
        private static readonly string AppId = PingIdProperties.app_id;

        private static string pairingKey = "";


        public static PingIDSdkApiUtility ApiHelper { get; set; } = new PingIDSdkApiUtility(AccountId, ApiKey, Token);


        /*
         * Registration of a device behind the scenes means that during user authentication,
         * a customer server communicates with PingID SDK to generate a token. This token allows pairing a device to the user. 
         * The user is not aware of this, and is not required to type or scan anything.
         * Automatic pairing has the advantage of good user experience: PingID SDK works behind the scenes, 
         * with minimal interaction with a user.
         */

            public static RegistrationToken CreateRegistrationToken(string pairkey)
        {
            var apiEndpoint = string.Format(RegistrationTokenBasePath, Constants.BasePath, AccountId, AppId);

            PingIdProperties.APIText = apiEndpoint;

            string payloadtemp ="";
            string pairKey = "";

            var configuration = new RegistrationToken
            {
                PayLoad = payloadtemp,
                IgnoreValidation = true,
                PairingKey = pairKey

            };




            // var regconfig = new RegistrationToken
            var createdRegistrationToken = ApiHelper.PostRequest<RegistrationToken>(apiEndpoint,configuration);


                return createdRegistrationToken;


        }
        /*
         * Creates email configuration with the parameters:
         * * locale=Constants.DefaultLocale (en)
         * * type=Constants.DefaultAuthType (pairing)
         * * fromAddress=Constants.DefaultFromAddress (noreply@pingidentity.com)
         * * EmailSubject = Constants.DefaultAuthEmailSubject (Welcome!)
         * * EmailBody = the content PindIDSDKHelper/EmailBodyContent/pairingEmailBody.html
         */
        public static EmailConfiguration CreatePairingEmailConfiguration()
        {
            var apiEndpoint = string.Format(EmailConfigurationsBasePathTemplate, Constants.BasePath, AccountId, AppId);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

            var bytes = File.ReadAllBytes(Constants.DefaultPairingEmailFilePath);
            var emailBody = Convert.ToBase64String(bytes);
            var configuration = new EmailConfiguration
            {
                EmailBodyEncoding = EmailBodyEncoding.Base64,
                Locale = Constants.DefaultLocale,
                Type = Constants.DefaultPairingType,
                FromAddress = Constants.DefaultFromAddress,
                EmailSubject = Constants.DefaultPairingEmailSubject,
                EmailBody = emailBody
            };
            var createdEmailConfiguration = ApiHelper.PostRequest<EmailConfiguration>(apiEndpoint, configuration);
            return createdEmailConfiguration;
        }

        /*
         * Creates email configuration with the parameters:
         * * locale=Constants.DefaultLocale (en)
         * * type=Constants.DefaultAuthType (auth_from_mobile)
         * * fromAddress=Constants.DefaultFromAddress (noreply@pingidentity.com)
         * * EmailSubject = Constants.DefaultAuthEmailSubject (New authentication device added)
         * * EmailBody = the content PindIDSDKHelper/EmailBodyContent/authFromMobileEmailBody.html
         */
        public static EmailConfiguration CreateAuthFromMobileEmailConfiguration()
        {
            var apiEndpoint = string.Format(EmailConfigurationsBasePathTemplate, Constants.BasePath, AccountId, AppId);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;
            var bytes = File.ReadAllBytes(Constants.DefaultAuthFromMobileEmailFilePath);
            var emailBody = Convert.ToBase64String(bytes);
            var configuration = new EmailConfiguration
            {
                EmailBodyEncoding = EmailBodyEncoding.Base64,
                Locale = Constants.DefaultLocale,
                Type = Constants.DefaultAuthFromMobileType,
                FromAddress = Constants.DefaultFromAddress,
                EmailSubject = Constants.DefaultAuthFromMobileEmailSubject,
                EmailBody = emailBody
            };
            var createdEmailConfiguration = ApiHelper.PostRequest<EmailConfiguration>(apiEndpoint, configuration);
            return createdEmailConfiguration;
        }

        /*
         * Creates email configuration with the parameters:
         * * locale=Constants.DefaultLocale (en)
         * * type=Constants.DefaultAuthType (authentication)
         * * fromAddress=Constants.DefaultFromAddress (noreply@pingidentity.com)
         * * EmailSubject = Constants.DefaultAuthEmailSubject (New Authentication Request)
         * * EmailBody = the content PindIDSDKHelper/EmailBodyContent/authEmailBody.html
         */
        public static EmailConfiguration CreateAuthEmailConfiguration()
        {
            var apiEndpoint = string.Format(EmailConfigurationsBasePathTemplate, Constants.BasePath, AccountId, AppId);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

            var bytes = File.ReadAllBytes(Constants.DefaultAuthEmailFilePath);
            var emailBody = Convert.ToBase64String(bytes);
            var configuration = new EmailConfiguration
            {
                EmailBodyEncoding = EmailBodyEncoding.Base64,
                Locale = Constants.DefaultLocale,
                Type = Constants.PFEmailAuthType,
                FromAddress = Constants.DefaultFromAddress,
                EmailSubject = Constants.DefaultAuthEmailSubject,
                EmailBody = emailBody
            };
            var createdEmailConfiguration = ApiHelper.PostRequest<EmailConfiguration>(apiEndpoint, configuration);
            return createdEmailConfiguration;
        }

        /**
        * Start pairing user with email device
        * @remarks In order to finalize the pairing, the id property of the returned EmailOfflinePairing object must be used in FinalizeEmailPairing()
        * @param username the user name
        * @param email the email address to be used in order to send messages. 
        * @return the pairing 
        */
        public static EmailOfflinePairing PairingEmail(string username, string email)
        {
            var apiEndpoint = string.Format(EmailPairingBasePathTemplate, Constants.BasePath, AccountId, AppId,
                username);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

            var pairing = new EmailOfflinePairing
            {
                Lcoale = Constants.DefaultLocale,
                Type = Constants.DefaultPairingType,
                Recipient = email,
                AutomaticPairing = PingIdProperties.autopair
            };
            var createdPairing = ApiHelper.PostRequest<EmailOfflinePairing>(apiEndpoint, pairing);
            return createdPairing;
        }
        // Native Mobile app Post request to create paring key
        //accounts/{accountId}/applications/{applicationId}/pairingkeys
        //

        public static CreateMobilePairingKey CreatePairingKey(string pairingKey)
        {
            var apiEndpoint = string.Format(PairMobileNativeTemplate, Constants.BasePath, AccountId, AppId);// + "/" + pairingKey;
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;


            var pairing = new CreateMobilePairingKey
            {
               PairingData = pairingKey
            };
            var createdPairing = ApiHelper.PostRequest<CreateMobilePairingKey>(apiEndpoint, pairing);

            PingIdProperties.PairCode = createdPairing.Id.ToString();


            return createdPairing;



        }
        /**
         * get auth status
         * @param the authID
         * #return the auth status
         */

        public static Authentication AuthStatus(string username,string authID)
        {
           

            var apiEndpoint = string.Format(AuthAPItemplate, Constants.BasePath, AccountId, AppId, authID);

            apiEndpoint = apiEndpoint  + username + "/authentications/" + authID;
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

            var authstatus = ApiHelper.GetRequest<Authentication>(apiEndpoint);

            return authstatus;


        }


     



        /**
        * Get user
        * @param username the user name
        * @return the user from "PingID SDK". null - if not exist
        */
        public static User GetUser(string username)
        {
            var apiEndpoint = string.Format(UsersByAppAndIDPathTemplate, Constants.BasePath, AccountId, AppId, username);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

            var user = ApiHelper.GetRequest<User>(apiEndpoint);
            return user;
        }

        /**
         * get users expanded
         * @param username the user name
         * @return the user from "PingID SDK". null - if not exist
         */

            public static User GetUserExpanded(string username)
        {
            var apiEndpoint = string.Format(UsersExpanded, Constants.BasePath, AccountId, AppId, username);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

            var user = ApiHelper.GetRequest<User>(apiEndpoint);
            return user;
        }



         // Native Mobile App Manual Pairing get request

         //
         //"https://sdk.pingid.com/pingid/v1/accounts/6438823d-671c-42e7-9b1e-8960494ef5e4/applications/c05d7f3d-fa34-42d1-b930-49a18f6fef33/pairingkeys"
         //"https://sdk.pingid.com/pingid/v1/accounts/6438823d-671c-42e7-9b1e-8960494ef5e4/applications/355aed99-6ddc-4863-8d99-48e9620e978d/pairingkeys"


         public static NativeMobileAppPairing PairingMobile(string pairingKey)
         {
             var apiEndpoint = string.Format(PairMobileNativeTemplate, Constants.BasePath, AccountId, AppId) + "/" + pairingKey;
             //update lable text to be used
             PingIdProperties.APIText = apiEndpoint;


             // var createdPairing = ApiHelper.PostRequest<NativeMobileAppPairing>(apiEndpoint, pairingKey);

             var createdPairing = ApiHelper.GetRequest< NativeMobileAppPairing>(apiEndpoint);


             PingIdProperties.PairCode = createdPairing.PairingData;


             return createdPairing;

         }




         //delete a user
         public static User DeleteUser(string username)
         {
             var apiEndpoint = string.Format(UsersByAccountBasePathTemplate, Constants.BasePath, AccountId, AppId, username)+"/"+username;

             //update lable text to be used
             PingIdProperties.APIText = apiEndpoint;

            //var delete = ApiHelper.DeleteRequest<User>(apiEndpoint);
            //  String deleteAPI = apiEndpoint.ToString();


            //var user = ApiHelper.GetRequest<User>(apiEndpoint);
           // var user = ApiHelper.DeleteRequest(apiEndpoint);
            ApiHelper.DeleteRequest(apiEndpoint);


            //var user ="";



            //try
            //{
            //    ApiHelper.DeleteRequest(apiEndpoint);
            //}
            //catch
            //{

            //}



            return null;



         }
         
         /**
         * Get all the devices of user
         * @param username the user name
         * @return the user's device list
         */
        public static List<Device> GetUserDevices(string username)
        {
            var apiEndpoint = string.Format(DevicesByApplicationBasePathTemplate, Constants.BasePath, AccountId, AppId, username);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

            var devices = ApiHelper.GetCollectionRequest<Device>(apiEndpoint, "devices");
            return devices;
        }

        /**
        * Get the application's email configurations with a specific type and locale
        * @return the application's email configurations with the locale and type
        * @remarks the returned list might be empty or have one object, a single application can not have two configurations with the same type and locale
        */
        public static List<EmailConfiguration> GetEmailConfigurationByTypeAndLocale(string type, string locale)
        {
            var apiEndpoint = string.Format(EmailConfigurationByTypeAdeLocalePathTemplate,
                Constants.BasePath, AccountId, AppId, type, locale);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

            var configurations = ApiHelper.GetCollectionRequest<EmailConfiguration>(apiEndpoint, "emailconfigurations");
            return configurations;
        }

        /**
        * Get the application's email configurations
        * @return all the application's email configurations
        */
        public static List<EmailConfiguration> GetEmailConfigurations()
        {
            var apiEndpoint = string.Format(EmailConfigurationsBasePathTemplate, Constants.BasePath, AccountId, AppId);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

            var configurations = ApiHelper.GetCollectionRequest<EmailConfiguration>(apiEndpoint, "emailconfigurations");

            return configurations;
        }

        /**
        * Adds a new user to the account
        * @param username the user name
        * @return the user that created
        */
        public static User CreateUser(string username, string firstName, string lastName)
        {
            
                var apiEndpoint = string.Format(UsersByAccountBasePathTemplate, Constants.BasePath, AccountId);
                //update lable text to be used
                PingIdProperties.APIText = apiEndpoint;

                var user = new User
                {
                    Username = username,
                    FirstName = firstName,
                    LastName = lastName
                };
                user = ApiHelper.PostRequest<User>(apiEndpoint, user);

                return user;

        }

        public static VoicePairing PairingVoice(string username, string phoneNumber)
        {
            var apiEndpoint = string.Format(VoicePairingBasePathTemplate, Constants.BasePath, AccountId, AppId, username);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

            var pairing = new VoicePairing
            {
                PhoneNumber = phoneNumber,
                Message = PingIdProperties.DEFAULT_VOICE_PAIRING_MESSAGE,
                Local = Constants.DefaultLocale,
                Voice = Constants.DefaultVoice,
                AutomaticPairing = PingIdProperties.autopair
            };
            var createdPairing = ApiHelper.PostRequest<VoicePairing>(apiEndpoint, pairing);
            return createdPairing;

        }

        public static void FinalizeVoicePairing(string username, string id, string otp, string deviceNickName)
        {
            var apiEndpoint = string.Format(FinalizeVoicePairingBasePathTemplate, Constants.BasePath, AccountId, AppId,username, id);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

            var finalizePairing = new FinalizePairing
            {
                //The user has 3 attempts to enter correct otp
                Otp = otp,
                //The device nickname can be empty, in this case the SDK will set a default name
                DeviceNickname = deviceNickName
            };
            ApiHelper.PutRequestNoContent<FinalizePairing>(apiEndpoint, finalizePairing);

            //return createdPairing;

        }
        public static VoicePairing VoicePairStatus(string username, string PairID)
        {


            var apiEndpoint = string.Format(VoicePairStatustemplate, Constants.BasePath, AccountId, AppId, PairID);

            apiEndpoint = apiEndpoint + username + "/voicepairings/" + PairID;
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

            var VoicePairstatus = ApiHelper.GetRequest<VoicePairing>(apiEndpoint);

            return VoicePairstatus;


        }



        /**
        * Start pairing user with SMS device
        * @remarks In order to finalize the pairing, the id property of the returned SmsOfflinePairing object must be used in FinalizeSmsPairing()
        * @param username the user name
        * @param phoneNumber the phone number to be used in order to send SMS messages. Has to include country code (for e.g. 15417543010) 
        * @return the pairing. 
        */
        public static SmsOfflinePairing PairingSms(string username, string phoneNumber)
        {
            var apiEndpoint = string.Format(SmsPairingBasePathTemplate, Constants.BasePath, AccountId, AppId, username);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

            var pairing = new SmsOfflinePairing
            {
                PhoneNumber = phoneNumber,
                Message = PingIdProperties.DEFAULT_SMS_PAIRING_MESSAGE,
                Sender = Constants.DefaultSenderName,
                AutomaticPairing = PingIdProperties.autopair
            };
            var createdPairing = ApiHelper.PostRequest<SmsOfflinePairing>(apiEndpoint, pairing);
            return createdPairing;

        }
        
        /**
        * Finalize SMS offline pairing with "PingID SDK"
        * @param username the user name
        * @param id the pairing operation id (this ID is generated when the pairing process begins)
        * @param otp the otp received from the user via SMS
        * @param deviceNickName the device name (In case of empty, the server sets a default name)
        */
        public static void FinalizeSmsPairing(string username, string id, string otp, string deviceNickName)
        {
            var apiEndpoint = string.Format(FinalizeSmsPairingPathTemplate, Constants.BasePath, AccountId, AppId,
                username, id);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

            var finalizePairing = new FinalizePairing
            {
                //The user has 3 attempts to enter correct otp
                Otp = otp,
                //The device nickname can be empty, in this case the SDK will set a default name
                DeviceNickname = deviceNickName
            };
            ApiHelper.PutRequestNoContent<FinalizePairing>(apiEndpoint, finalizePairing);
        }

        /**
        * Finalize email offline pairing with "PingID SDK"
        * @param username the user name
        * @param id the pairing operation id (this ID is generated when the pairing process begins)
        * @param otp the otp received from the user via email
        * @param deviceNickName the device name (In case of empty, the server sets a default name)
        */
        public static void FinalizeEmailPairing(string username, string id, string otp, string deviceNickName)
        {
            var apiEndpoint = string.Format(FinalizeEmailPairingPathTemplate, Constants.BasePath, AccountId, AppId,
                username, id);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

            var finalizePairing = new FinalizePairing
            {
                //The user has 3 attempts to enter correct otp
                Otp = otp,
                //The device nickname can be empty, in this case the SDK will set a default name
                DeviceNickname = deviceNickName
            };
            ApiHelper.PutRequestNoContent<FinalizePairing>(apiEndpoint, finalizePairing);
        }

        /**
        * Delete user's device with "PingID SDK"
        * @remarks the user will not be able to authenticate with the device after the device is deleted
        * @param username the user name
        * @param id the id of the device.
        */
        public static void DeleteDevice(string username, string id)
        {
            var apiEndpoint = string.Format(DevicePathByIDTemplate, Constants.BasePath, AccountId, username, id);
            ApiHelper.DeleteRequest(apiEndpoint);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

        }

        /**
        * Delete application's email configuration by ID
        * @param emailConfigurationId the email configuration ID
        */
        public static void DeleteEmailConfiguration(string emailConfigurationId)
        {
            var apiEndpoint = string.Format(EmailConfigurationByIDPathTemplate, Constants.BasePath, AccountId,
                AppId, emailConfigurationId);
            ApiHelper.DeleteRequest(apiEndpoint);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

        }

        /*
        * Authenticate with "PingID SDK"
        * Stat offline authentication operation (Sms/Email) with the user's primary device
        * @see StartAuthentication(string username, string deviceId)
        */
        public static Authentication StartAuthentication(string username)
        {
            return StartAuthentication(username, null);
        }

        /**
        * Authenticate with "PingID SDK"
        * Stat offline authentication operation (Sms/Email)
        * @remarks In order to finalize the authentication, the id of the returned Authentication object must be used in FinalizeAuthentication()
        * @param username the user name
        * @param deviceId the device the authentication should be preformed with
        * @return the authentication.
        */
        public static Authentication StartAuthentication(string username, string deviceId)
        {
            var apiEndpoint = string.Format(AuthenticationBasePathTemplate, Constants.BasePath, AccountId, AppId,
                username);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

            var UserAuthentication = new Authentication
            {
                AuthenticationType = AuthenticationType.Authenticate,
                SmsMessage = PingIdProperties.DEFAULT_SMS_AUTHENTICATION_MESSAGE,
                SmsSender = Constants.DefaultSenderName,
                //SmsSender = "1234",
                Locale = Constants.DefaultLocale,
                voiceMessage = PingIdProperties.DEFAULT_VOICE_AUTHENICATION_MESSAGE,
                EmailConfigurationType = Constants.DefaultAuthType,
                DeviceId = deviceId
            };
            var createdAuthentication = ApiHelper.PostRequest<Authentication>(apiEndpoint, UserAuthentication);
            return createdAuthentication;
        }

        /**
        * Finalize authentication with "PingID SDK"
        * @param username the user name
        * @param id the authentication operation id.
        * @param otp the otp received from the user via email/sms
        * @return the authentication 
        * @remarks Status property in the returned object specified the authentication operation outcome
        */
        public static Authentication FinalizeAuthentication(string username, string id, string otp)
        {
            var apiEndpoint = string.Format(FinalizeAuthenticationPathTemplate, Constants.BasePath, AccountId, AppId, username, id);
            //update lable text to be used
            PingIdProperties.APIText = apiEndpoint;

            var finalizeAuthentication = new FinalizeAuthentication
            {
                //The user has 3 attempts to enter correct otp
                Otp = otp
            };
            var createdAuthentication = ApiHelper.PutRequest<Authentication>(apiEndpoint, finalizeAuthentication);
            return createdAuthentication;
        }
    }
}