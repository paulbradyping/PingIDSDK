﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PingIDSDK.PingIDSDKHelper
{
    public static class Constants
    {
        public const string SdkHost = "sdk.pingid.com";
        public const string BasePath = "https://" + SdkHost + "/pingid/v1/accounts";

      //  public const string DefaultSmsPairingMessage = "";
        public const string DefaultSmsAuthenticationMessage = "Your PingID SDK authentication code is: ${otp}";
        public const string DefaultSenderName = null;
        //public const string DefaultSenderName = "123";


        public const string DefaultLocale = "en";
        public const string DefaultFromAddress = "noreply@pingidentity.com";

        public const string DefaultPairingType = "pairing";
        public const string DefaultPairingEmailFilePath = "C:/MyProgramsPing/MyProgramsPing2017/MyProgramsPing2017/PingIDSDK/PingIDSDK/PingIDSDKHelper/EmailBodyContent/pairingEmailBody.html";
        public const string DefaultPairingEmailSubject = "Welcome";

        public const string DefaultAuthFromMobileType = "auth_from_mobile";
        public const string DefaultAuthFromMobileEmailFilePath = "C:/MyProgramsPing/MyProgramsPing2017/MyProgramsPing2017/PingIDSDK/PingIDSDK/PingIDSDKHelper/EmailBodyContent/authFromMobileEmailBody.html";
        public const string DefaultAuthFromMobileEmailSubject = "New authentication device added";

        public const string DefaultAuthType = "authentication";
        public const string PFEmailAuthType = "auth_without_payload";

        //C:\MyProgramsPing\MyProgramsPing2017\MyProgramsPing2017\PingIDSDK\PingIDSDK\PingIDSDKHelper\EmailBodyContent
        public const string DefaultAuthEmailFilePath = "C:/MyProgramsPing/MyProgramsPing2017/MyProgramsPing2017/PingIDSDK/PingIDSDK/PingIDSDKHelper/EmailBodyContent/authEmailBody.html";
        public const string DefaultAuthEmailSubject = "New Authentication Request";

        public const string DefaultFirstName = "john";
        public const string DefaultLastName = "doe";

       // public const string DefaultVoicePairingMessage = "Your PingID SDK pairing code is ${otp} <repeatMessage val=1> Your Code is ${otp} </repeatMessage>";
        // public const string DefaultVoiceAuthenticationMessage = "Hello your Custom PingID SDK Authentication Code is ${otp}";
        public const string DefaultVoice = "Alice";
        public const string DefaultVoiceLocal = "en_US";


    }
}