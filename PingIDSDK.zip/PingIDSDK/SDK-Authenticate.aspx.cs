﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PingIDSDK.ErrorHandling;
using PingIDSDK.PingIDSDKHelper;
using PingIDSDK.RestApiResources;
using System.Timers;

namespace PingIDSDK
{
    public partial class SDK_Authenticate : System.Web.UI.Page
    {

        static string username = "";
        static string email = "";
        static string otpPairing = "";
        static string deviceNickName = "";
        static string phoneNumber = "";
        static string pairingType = "";
        static string pairingData = "";
        static string deviceId = "";


        bool userexists;


        //authentication and pairing objects shared by all the buttons on the form
        static EmailOfflinePairing createdEmailPairing;
        static Authentication createdAuthentication;
        static Authentication finalizedAuthentication;
        static SmsOfflinePairing createdSmsPairing;
        static VoicePairing createdVoicePairing;
       // static RegistrationTokenPairing registrationTokenPairing;




        protected void Page_Load(object sender, EventArgs e)
        {

        }


        protected void verify()
        {
            if (ChkPairVerify.Checked == true)
            {
                PingIdProperties.autopair = false;
               // BtnPairComplete.Enabled = false;

            }
            else if (ChkPairVerify.Checked==false)
            {
                PingIdProperties.autopair = true;
                BtnPairComplete.Enabled = false;
            }

        }


        protected void Cleanup()
        {
            LblSDKInfo.Text = "";
            LblError.Text = "";
            LblSDKInfo.Text = "";
            LblSDKInfo.Text = "";
            TxbSMSNumber.Text = "";
            TxbEmailAddress.Text = "";
            TxbVoice.Text = "";
            TxbFinalAuth.Text = "";
            TxbUserInfo.Text = "";
            TxbPairVerify.Text = "";
            DevicesList.Items.Clear();
            LstDevicName.Items.Clear();
            lstDeviceData.Items.Clear();
           






        }
        protected void BtnGetDevices_Click(object sender, EventArgs e)
        {
            DevicesList.Items.Clear();
            LstDevicName.Items.Clear();
            if (btnAuthStatus.Enabled==true)btnAuthStatus.Enabled = false;
            if (btnVoicePairStatus0.Enabled == true) btnVoicePairStatus0.Enabled = false;

            Cleanup();

            try
            {
                
                username = TxbUserName.Text.Trim();

                
                List<Device> deviceList;
                try
                {
                    deviceList = CommonRequests.GetUserDevices(username);
                }
                catch (PingIDSdkException ex)
                {
                    LblError.Text = "Failed to get user's devices. details: {0} "+ ex;
                    return;
                }

                for (int x = 0;x<deviceList.Count;x++)
                {
                    DevicesList.Items.Add( deviceList[x].Id);
                    LstDevicName.Items.Add(deviceList[x].DeviceType);
                    lstDeviceData.Items.Add(deviceList[x].DeviceFingerprint);

                }

                BtnAuthenticate.Enabled = true;
                BtnDeleteDevice.Enabled = true;
                TxbFinalAuth.Enabled = true;
                TxbFinalAuth.Text = "";


                LblAPI.Text = PingIdProperties.APIText;
            }
            catch (Exception)
            {
                LblError.Text = "Failed to get user's devices. details";
                return;
            }

        }

        protected void BtnPairEmail_Click(object sender, EventArgs e)
        {

            BtnPairSMS.Enabled = false;
            BtnPairVoice.Enabled = false;
            BtnPairComplete.Enabled = true;

            if (TxbEmailAddress.Text !="" || TxbEmailAddress.Text.Contains("@")==true ||TxbVoice.Text!=""||TxbSMSNumber.Text!="")
            {

                try
                {

                    verify();

                    pairingType = "email";
                    username = TxbUserName.Text;


                    email = TxbEmailAddress.Text;
                    LblSDKInfo.Text = "Starting to pair user using email...";

                    createdEmailPairing = CommonRequests.PairingEmail(username, email);

                    if (ChkPairVerify.Checked==true)
                    {
                        LblSDKInfo.Text = "Enter the otp you got via email You can Also Enter device nickname(you may leave it empty)";

                    }
                    else
                    {
                        LblSDKInfo.Text = "Automatically paired no verification code sent";
                    }

                    LblAPI.Text = PingIdProperties.APIText;
                }

                catch (PingIDSdkException ex)
                {
                    LblError.Text = "Failed to start email pairing. details: {0}" + ex;

                }

            }
            else
            {
                LblError.Text = "Invalid Email Address!";
            }

        }

        protected void BtnEmailPairComplete_Click(object sender, EventArgs e)
        {
           
            BtnPairEmail.Enabled = true;
            BtnPairSMS.Enabled = true;
            BtnPairVoice.Enabled = true;

            try
            {
                //voice
                if (pairingType == "voice")
                {

                    otpPairing = TxbPairVerify.Text;

                    deviceNickName = TxbVoiceNick.Text;

                    CommonRequests.FinalizeVoicePairing(username, createdVoicePairing.Id, otpPairing,deviceNickName);

                    LblSDKInfo.Text = "Finished pairing with Voice!";
                    btnVoicePairStatus0.Enabled = false;
                }

                //Email
                if (pairingType == "email")
                {

                    otpPairing = TxbPairVerify.Text;

                    deviceNickName = TxbEmailNick.Text;
                    
                    CommonRequests.FinalizeEmailPairing(username, createdEmailPairing.Id, otpPairing,deviceNickName);

                    LblSDKInfo.Text = "Finished pairing with Email!";
                }
                //sms
                if (pairingType == "sms")
                {
                    otpPairing = TxbPairVerify.Text;

                    deviceNickName = TxbSMSNick.Text;
                    
                    CommonRequests.FinalizeSmsPairing(username, createdSmsPairing.Id, otpPairing, deviceNickName);
                    
                    LblSDKInfo.Text = "Finished pairing with SMS!";

                    

                }


                LblAPI.Text = PingIdProperties.APIText;

                BtnPairComplete.Enabled = false;
                
                Cleanup();

            }
            catch(PingIDSdkException ex)
            {
                LblError.Text = "Pairing Failed! " + ex;

            }
            

        }

        protected void BtnGetEmailTemplate_Click(object sender, EventArgs e)
        {
          
        }

        protected void BtnAuthenticate_Click(object sender, EventArgs e)
        {
           

            if (DevicesList.SelectedItem != null | LstDevicName.SelectedItem != null)
            {
                
                BtnFinalAuth.Enabled = true;

                BtnAuthenticate.Enabled = false;
                
                LblSDKInfo.Text = "Enter the id of the device you would like to authenticate with (leave empty for primary): ";


            if (DevicesList.SelectedItem == null)
                {
                    int devidIndex = LstDevicName.SelectedIndex;
                    deviceId = DevicesList.Items[devidIndex].ToString();
                }
                else
                {
                    deviceId = DevicesList.SelectedItem.ToString();
                }
                //LblSDKInfo.Text = "Start authentication...";

                try
                    {
                        createdAuthentication = string.IsNullOrWhiteSpace(deviceId)
                        ? CommonRequests.StartAuthentication(username)
                        : CommonRequests.StartAuthentication(username, deviceId);


                        LblSDKInfo.Text = "Enter your authentication otp: ";

                        LblAPI.Text = PingIdProperties.APIText;

                        LblSDKInfo.Text = createdAuthentication.Status.ToString();

                    // btnStatus.Enabled = true;
                    btnAuthStatus.Enabled = true;


                    }
                    catch (PingIDSdkException ex)
                    {
                     LblSDKInfo.Text = "Failed to start authentication. details: {0} " + ex;

                    }
                //end of the if to cehck if something is selected
            }
            else
            {
                LblError.Text = "You Must select Device Name or ID";
            }
        }

       

        protected void BtnFinalAuth_Click(object sender, EventArgs e)
        {
            BtnAuthenticate.Enabled = true;
            //BtnFinalAuth.Enabled = false;

            var otpAuthentication = TxbFinalAuth.Text;
            
            try
            {
                finalizedAuthentication =
                    CommonRequests.FinalizeAuthentication(username, createdAuthentication.Id,
                        otpAuthentication);
            }
            catch (PingIDSdkException ex)
            {
                LblError.Text=("Failed to finalize authentication. details: {0} "+ ex);
                
            }
            if (finalizedAuthentication.Status == AuthenticationStatus.Approved)
            {
                Cleanup();
                LblSDKInfo.Text="Finished Successful authentication!";
                

            }
            else
            {
                LblError.Text="Authentication Failed!, authentication status: {0} "+finalizedAuthentication.Status;
            }



            LblAPI.Text = PingIdProperties.APIText;

            //Cleanup();
        }

        protected void BtnDeleteDevice_Click(object sender, EventArgs e)
        {
            LblSDKInfo.Text="Enter the device ID to delete: ";
           // var deviceId = DevicesList.SelectedItem.ToString();

            if (DevicesList.SelectedItem == null)
            {
                int devidIndex = LstDevicName.SelectedIndex;
                deviceId = DevicesList.Items[devidIndex].ToString();
            }
            else
            {
                deviceId = DevicesList.SelectedItem.ToString();
            }
            try
            {
                CommonRequests.DeleteDevice(username, deviceId);

                LblSDKInfo.Text="Deleting device {0} "+ deviceId;
            }
            catch (PingIDSdkException ex)
            {
                LblError.Text="Failed to delete device. details: {0} "+ex;

            }

            LblAPI.Text = PingIdProperties.APIText;
        }

        protected void BtnPairSMS_Click(object sender, EventArgs e)
        {
            BtnPairVoice.Enabled = false;
            BtnPairEmail.Enabled = false;
            BtnPairComplete.Enabled = true;
            
           phoneNumber = TxbSMSNumber.Text;

            pairingType = "sms";

            verify();

            if (TxbEmailAddress.Text == "" & TxbVoice.Text == "" & TxbSMSNumber.Text !="")
            {
                LblSDKInfo.Text = "Text Message Pairing using phone number: ";
                try
                {
                    createdSmsPairing = CommonRequests.PairingSms(username, phoneNumber);
                    if (ChkPairVerify.Checked == true)
                    {
                        LblSDKInfo.Text = "Enter your OTP: ";

                    }
                    else
                    {
                        LblSDKInfo.Text = "Automatically paired no verification code sent";
                    }

                }
                catch (PingIDSdkException ex)
                {
                    LblError.Text = "Failed to start SMS pairing. details: {0} " + ex;

                }

                LblAPI.Text = PingIdProperties.APIText;


            }
            else
            {
                LblError.Text = "Invlaid SMS Number";
            }




        }

        protected void BtnPairVoice_Click(object sender, EventArgs e)
        {
            

           // BtnPairEmail.Enabled = false;
            //BtnPairSMS.Enabled = false;
            //BtnPairComplete.Enabled = true;
            btnVoicePairStatus0.Enabled = true;

            
            pairingType = "voice";
            
            phoneNumber = TxbVoice.Text;

            username = TxbUserName.Text;
            verify();

            if (TxbEmailAddress.Text == "" & TxbSMSNumber.Text == "" & TxbVoice.Text !="")
            {
                LblSDKInfo.Text = "Pairing using phone number...with area code if needed +14155552671): ";

                //   createdSmsPairing = CommonRequests.PairingSms(username, phoneNumber);

                
                try
                {
                createdVoicePairing = CommonRequests.PairingVoice(username, phoneNumber);

                    if (ChkPairVerify.Checked == true)
                    {
                        LblSDKInfo.Text = "Ring Ring, Enter the OTP Below: ";
                    }
                    else
                    {
                        LblSDKInfo.Text = "Automatically paired no Voice Call verification code sent";
                    }
                   


                }
                catch (PingIDSdkException ex)
                {
                LblError.Text = "Failed to start Voice pairing. details: {0} " + ex;

                }

                LblAPI.Text = PingIdProperties.APIText;
            }
            else
            {
                LblError.Text = "Invalid Voice Number";

            }
            
        }

        protected void BtnChkUser_Click(object sender, EventArgs e)
        {
            Cleanup();

            username = TxbUserName.Text;

            username = username.Trim();


            if (username != "")
            {

                try
                {

                    if(CommonRequests.GetUser(username)==null)
                    {
                        userexists = false;

                        LblSDKInfo.Text = "User Not Found...";

                        BtnCreateUser.Enabled = true;
                        BtnDeleteUser.Enabled = false;
                        btnGetUser.Enabled = false;
                        btnExtendeduserStatus.Enabled = false;
                    }
                    else
                    {
                        BtnCreateUser.Enabled = false;
                        BtnDeleteUser.Enabled = true;
                        btnGetUser.Enabled = true;
                        btnExtendeduserStatus.Enabled = true;

                        userexists = true;
                    }
                }
                catch(PingIDSdkException ex)
                {
                    LblError.Text = "Error Get user... " + ex;

                }
                
            }
            else
            {

                LblError.Text = "You Must Enter a Username";

            }

            if (userexists == true)
            {
                Panel1.Enabled = true;
                Panel2.Enabled = true;
              
                LblSDKInfo.Text = "User Found!";


                LblAPI.Text = PingIdProperties.APIText;

                BtnDeleteUser.Enabled = true;
                btnGetUser.Enabled = true;
                btnExtendeduserStatus.Enabled = true;

                

            }

        }

        protected void BtnCreateUser_Click(object sender, EventArgs e)
        {
            Cleanup();

            try
            {
                LblSDKInfo.Text = "Creating new user with username " + username;
                CommonRequests.CreateUser(username, Constants.DefaultFirstName, Constants.DefaultLastName);

                LblAPI.Text = PingIdProperties.APIText;
            }
            catch(PingIDSdkException ex)
            {
                LblError.Text = "Error creating user... " + ex;

            }

        }

        protected void BtnSendPush_Click(object sender, EventArgs e)
        {


            var deviceId = DevicesList.SelectedItem.ToString();

            try
            {
                createdAuthentication = string.IsNullOrWhiteSpace(deviceId)
                    ? CommonRequests.StartAuthentication(username)
                    : CommonRequests.StartAuthentication(username, deviceId);


                LblSDKInfo.Text = " Authentication Push Approved";

                
                LblAPI.Text = PingIdProperties.APIText;
            }
            catch (PingIDSdkException ex)
            {
                LblSDKInfo.Text = "Failed to start authentication. details: {0} " + ex;

            }
        }

        protected void BtnDeleteUser_Click(object sender, EventArgs e)
        {
            try
            {
                LblSDKInfo.Text = "Deleting user with username " + username;
                CommonRequests.DeleteUser(username);



                LblAPI.Text = PingIdProperties.APIText;
            }
            catch (PingIDSdkException ex)
            {
                LblError.Text = "Error Deleting user... " + ex;

            }

            BtnDeleteUser.Enabled = false;

        }

        protected void btnPairMobile_Click(object sender, EventArgs e)
        {
            try
            {

                // replace this with a rnd number
                pairingData = "ABC1234";
                LblSDKInfo.Text = "Pair Native Mobile App";

                CommonRequests.CreatePairingKey(pairingData).ToString();

                LblPairingCode.Text = PingIdProperties.PairCode;


                LblAPI.Text = PingIdProperties.APIText;

            }
            catch (PingIDSdkException ex)
            {
                LblError.Text = "Error Pairing Mobile...." + ex;

            }


        }

        protected void btnStatus_Click(object sender, EventArgs e)
        {
            try
            {

                //get teh ID.. 

                string authID = createdAuthentication.Id.ToString();

                ////get status...

                string checkauth = CommonRequests.AuthStatus(username, authID).ToString();

                LblSDKInfo.Text = "AuthStatus: " + checkauth.ToString();

            }
            catch (PingIDSdkException ex)
            {
                LblError.Text = "Error with users Status Expanded..." + ex;

            }


        }

        protected void btnGetUser_Click(object sender, EventArgs e)
        {
            try
            {

                string checkstatus = "";

                //CommonRequests.FinalizeAuthentication(username, createdAuthentication.Id);

                checkstatus = CommonRequests.GetUser(username).ToString();


                LblSDKInfo.Text = "UserStatus: " + checkstatus;

            }
            catch (PingIDSdkException ex)
            {
                LblError.Text = "Error with User Status ..." + ex;

            }
        }

        protected void btnExtendeduserStatus_Click(object sender, EventArgs e)
        {

            try
            {
                TxbUserInfo.Visible = true;

                string checkstatus = "";

                //CommonRequests.FinalizeAuthentication(username, createdAuthentication.Id);

                checkstatus = CommonRequests.GetUserExpanded(username).ToString();


                TxbUserInfo.Text = "UserStatusExpanded: " + checkstatus + " " + PingIdProperties.Responsedata;
            }
            catch (PingIDSdkException ex)
            {
                LblError.Text = "Error with users Status Expanded..." + ex;

            }

        }

        protected void btnVoicePairStatus0_Click(object sender, EventArgs e)
        {
            try
            {

                TxbUserInfo.Visible = true;

                string pairID = createdVoicePairing.Id.ToString();


                string checkpairingStatus = "";

                //CommonRequests.FinalizeAuthentication(username, createdAuthentication.Id);

                //checkpairingStatus = CommonRequests.GetUserExpanded(username).ToString();
                checkpairingStatus = CommonRequests.VoicePairStatus(username, pairID).ToString();

                TxbUserInfo.Text = "";

                TxbUserInfo.Text = "Read a Voice pairing resource: " + checkpairingStatus + " " + PingIdProperties.Responsedata;
            }
            catch (PingIDSdkException ex)
            {
                LblError.Text = "Error Read Reasource VOice Pairing...." + ex;

            }

        }

        protected void btnAuthStatus_Click(object sender, EventArgs e)
        {
            try
            {

                //get teh ID.. 

                string authID = createdAuthentication.Id.ToString();

                ////get status...

                string checkauth = CommonRequests.AuthStatus(username, authID).ToString();

                LblSDKInfo.Text = "AuthStatus: " + checkauth.ToString();

            }
            catch (PingIDSdkException ex)
            {
                LblError.Text = "Error with users Status Expanded..." + ex;

            }

        }

        protected void btnRegTokenPair_Click(object sender, EventArgs e)
        {
            //accounts/{accountId}/applications/{applicationId}/users/{username}/registrationtokens
            //
            string pairingKey = LblPairingCode.Text;

            string checkreg = CommonRequests.CreateRegistrationToken(pairingKey).ToString();

            LblSDKInfo.Text = "RegistrationToken" + checkreg.ToString();



        }
    }
}