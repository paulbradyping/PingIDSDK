﻿using System.Runtime.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace PingIDSDK.ErrorHandling
{
    [DataContract]
    [JsonConverter(typeof(StringEnumConverter))]
    public enum InternalErrorCode
    {
        [EnumMember(Value = "INVALID_VALUE")]
        InvalidValue,
        [EnumMember(Value = "REQUIRED_VALUE")]
        RequiredValue,
        [EnumMember(Value = "EMPTY_VALUE")]
        EmptyValue,
        [EnumMember(Value = "OUT_OF_RANGE")]
        OutOfRange,
        [EnumMember(Value = "SIZE_LIMIT_EXCEEDED")]
        SizeLimitExceeded,
        [EnumMember(Value = "NOT_FOUND")]
        NotFound,
        [EnumMember(Value = "INVALID_PATTERN")]
        InvalidPattern,
        [EnumMember(Value = "RESOURCE_IN_USE")]
        ResourceInUse,
        [EnumMember(Value = "UNIQUE_VALUE_REQUIRED")]
        UniqueValueRequired,
        [EnumMember(Value = "SERVICE_ERROR")]
        ServiceError,
        [EnumMember(Value = "DEVICE_BYPASSED")]
        DeviceBypassed,
        [EnumMember(Value = "DEVICE_IGNORED")]
        DeviceIgnored,
        [EnumMember(Value = "DEVICE_BLOCKED")]
        DeviceBlocked,
        [EnumMember(Value = "APPLICATION_DISABLED")]
        ApplicationDisabled,
        [EnumMember(Value = "USER_DISABLED")]
        UserDisabled,
        [EnumMember(Value = "APPLICATION_SHARED_WITH_NON_EXIST_ID")]
        ApplicationSharedWithNonExistID,
        [EnumMember(Value = "INVALID_PRODUCTION_CERTIFICATE")]
        InvalidProductionCertificate,
        [EnumMember(Value = "INVALID_SANDBOX_CERTIFICATE")]
        InvalidSandboxCertificate,
        [EnumMember(Value = "PRODUCTION_CERTIFICATE_EXPIRED")]
        ProductionCertificateExpired,
        [EnumMember(Value = "SANDBOX_CERTIFICATE_EXPIRED")]
        SandboxCertificateExpired,
        [EnumMember(Value = "PRODUCTION_CERTIFICATE_FAIL_TO_CONNECT")]
        ProductionCertificateFailToConnect,
        [EnumMember(Value = "SANDBOX_CERTIFICATE_FAIL_TO_CONNECT")]
        SandboxCertificateFailToConnect,
        [EnumMember(Value = "FCM_FAIL_TO_CONNECT")]
        FcmFailToConnect,
        [EnumMember(Value = "INVALID_USER_STATUS")]
        InvalidUserStatus,
        [EnumMember(Value = "RESOURCE_ALREADY_EXISTS")]
        ResourceAlreadyExists,
        [EnumMember(Value = "SMS_QUOTA_EXCEEDED")]
        SmsQuotaExceeded,
        [EnumMember(Value = "SMS_NOT_ENABLED")]
        SmsNotEnabled,
        [EnumMember(Value = "RETRY_LIMIT_EXCEEDED")]
        RetryLimitExceeded,
        [EnumMember(Value = "EMAIL_NOT_ENABLED")]
        EmailNotEnabled
    }
}