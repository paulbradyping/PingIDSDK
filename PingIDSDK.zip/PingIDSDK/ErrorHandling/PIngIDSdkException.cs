﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PingIDSDK.ErrorHandling
{
    public class PingIDSdkException : Exception
    {
        private int _pingIDSdkResponseStatus;
        private RestAPIError _pingIDSdkError;

        public PingIDSdkException(string msg) : base(string.Format("PingID SDK Error: {0}", msg))
        {
        }

        public PingIDSdkException(int status, string msg) : this(
            string.Format("PIngID SDK Error. HTTP status: {0}. error: {1}", status, msg))
        {
            _pingIDSdkResponseStatus = status;
        }

        public PingIDSdkException(int status, RestAPIError pingIDSdkError) : this(pingIDSdkError == null
            ? "PIngID SDK error is null"
            : string.Format("PIngID SDK Error. HTTP status: {0}. error: {1}", status, pingIDSdkError))
        {
            _pingIDSdkResponseStatus = status;
            SetPingIDSdkError(pingIDSdkError);
        }

        public int GetPingIDSdkResponseStatus()
        {
            return _pingIDSdkResponseStatus;
        }

        public void SetPingIDSdkResponseStatus(int pingIDSdkResponseStatus)
        {
            this._pingIDSdkResponseStatus = pingIDSdkResponseStatus;
        }

        public RestAPIError GetPingIDSdkError()
        {
            return _pingIDSdkError;
        }

        public void SetPingIDSdkError(RestAPIError pingIDSdkError)
        {
            this._pingIDSdkError = pingIDSdkError;
        }

        public override string ToString()
        {
            return string.Format("[PIngIDSdkException status={0}, message={1}]",
                GetPingIDSdkResponseStatus(),
                GetPingIDSdkError() == null ? "" : GetPingIDSdkError().ToString());
        }
    }
}