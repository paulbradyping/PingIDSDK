﻿using System.Runtime.Serialization;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;


namespace PingIDSDK.ErrorHandling
{
    [DataContract]
    [JsonConverter(typeof(StringEnumConverter))]
    public enum ErrorCode
    {
        [EnumMember(Value = "INVALID_DATA")]
        InvalidData,
        [EnumMember(Value = "REQUEST_FAILED")]
        RequestFailed,
        [EnumMember(Value = "INVALID_REQUEST")]
        InvalidRequest,
        [EnumMember(Value = "NOT_FOUND")]
        NotFound,
        [EnumMember(Value = "UNAUTHORIZED_REQ")]
        UnauthorizedReq,
        [EnumMember(Value = "UNEXPECTED_ERROR")]
        UnexpectedError
    }
}