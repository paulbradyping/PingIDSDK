﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PingIDSDK.ErrorHandling
{
    public class SignatureException : GeneralSecurityException
    {
        public SignatureException()
        {
        }

        public SignatureException(string msg) : base(msg)
        {
        }

        public SignatureException(string message, Exception cause) : base(message, cause)
        {
        }
    }
}