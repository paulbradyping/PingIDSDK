﻿using System.Text;
using Newtonsoft.Json;

namespace PingIDSDK.ErrorHandling
{
    public class ErrorInformation
    {
        public ErrorInformation()
        {
        }

        public ErrorInformation(string trackingIdentifier)
        {
            TrackingIdentifier = trackingIdentifier;
        }

        [JsonProperty(PropertyName = "trackingIdentifier")]
        public string TrackingIdentifier { get; }

        public override string ToString()
        {
            var sb = new StringBuilder("ErrorInformation{");
            sb.Append("trackingIdentifier='").Append(TrackingIdentifier).Append('\'');
            sb.Append('}');
            return sb.ToString();
        }
    }
}