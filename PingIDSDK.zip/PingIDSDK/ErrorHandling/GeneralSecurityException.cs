﻿using System;


namespace PingIDSDK.ErrorHandling
{
    public class GeneralSecurityException : Exception
    {
        public GeneralSecurityException()
        {
        }

        public GeneralSecurityException(string msg) : base(msg)
        {
        }

        public GeneralSecurityException(string message, Exception cause) : base(message, cause)
        {
        }
    }
}