﻿using System.Text;
using Newtonsoft.Json;


namespace PingIDSDK.ErrorHandling
{
    public abstract class Error
    {
        protected Error()
        {
        }

        protected Error(string message)
        {
            Message = message;
        }

        protected Error(string message, string target)
        {
            Message = message;
            Target = target;
        }

        protected Error(string message, string target, ErrorInformation errorInformation)
        {
            Message = message;
            Target = target;
            ErrorInformation = errorInformation;
        }

        [JsonProperty(PropertyName = "message")]
        public string Message { get; set; }

        [JsonProperty(PropertyName = "target")]
        public string Target { get; set; }

        [JsonProperty(PropertyName = "innerError")]
        public ErrorInformation ErrorInformation { get; set; }

        public override string ToString()
        {
            {
                var sb = new StringBuilder("Error{");
                sb.Append("message='").Append(Message).Append('\'');
                sb.Append(", target='").Append(Target).Append('\'');
                sb.Append(", errorInformation=").Append(ErrorInformation);
                sb.Append('}');
                return sb.ToString();
            }
        }
    }
}