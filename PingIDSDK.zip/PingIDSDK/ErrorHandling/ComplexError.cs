﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newtonsoft.Json;

namespace PingIDSDK.ErrorHandling
{
    public class ComplexError : Error
    {
        public ComplexError() : this(null, null, null, null)
        {
        }

        public ComplexError(ErrorCode code, string message) : this(code, message, null, null)
        {
        }

        public ComplexError(ErrorCode code, string message, string target) : this(code, message, target, null)
        {
        }

        public ComplexError(ErrorCode? code, string message, string target, ErrorInformation errorInformation) : base(
            message, target, errorInformation)
        {
            Code = code;
            Details = new List<InternalError>();
        }

        public void AddInternalError(InternalError internalError)
        {
            Details.Add(internalError);
        }

        [JsonProperty(PropertyName = "id")]
        public string Id { get; set; }

        [JsonProperty(PropertyName = "details")]
        public List<InternalError> Details { get; set; }

        [JsonProperty(PropertyName = "code")]
        public ErrorCode? Code { get; set; }

        public override string ToString()
        {
            var sb = new StringBuilder("RestAPIError{");
            sb.Append("id=").Append(Id);
            var detailsstring = string.Join(", ", Details.Select(internalError => internalError.ToString()).ToArray());
            sb.Append("details=[").Append(detailsstring);
            sb.Append("], code=").Append(Code);
            sb.Append('}');
            return sb.ToString();
        }
    }
}