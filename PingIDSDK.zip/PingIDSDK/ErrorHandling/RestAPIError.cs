﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PingIDSDK.ErrorHandling
{
    public class RestAPIError : ComplexError
    {
        public RestAPIError()
        {
        }

        public RestAPIError(ErrorCode code, string message) : base(code, message, null)
        {
        }

        public RestAPIError(ErrorCode code, string message, string target) : base(code, message, target, null)
        {
        }

        public RestAPIError(ErrorCode code, string message, string target, ErrorInformation errorInformation) : base(
            code, message, target, errorInformation)
        {
        }
    }
}