﻿using System.Text;
using Newtonsoft.Json;

namespace PingIDSDK.ErrorHandling
{
    public class InternalError : Error
    {
        public InternalError()
        {
        }

        public InternalError(InternalErrorCode code, string message) : this(code, message, null)
        {
        }

        public InternalError(InternalErrorCode code, string message, string target) : base(message, target)
        {
            Code = code;
        }

        [JsonProperty(PropertyName = "code")]
        public InternalErrorCode? Code { get; }

        public override string ToString()
        {
            var sb = new StringBuilder("InternalError{");
            sb.Append("code=").Append(Code);
            sb.Append(", message=").Append(Message);
            sb.Append(", target=").Append(Target);
            sb.Append('}');
            return sb.ToString();
        }
    }
}