﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PingIDSDK
{
    class PingIdProperties
    {
        public static readonly string basePath = "v1/accounts";
        //MDI0OGYxZjQtMmVjZS00NGQ0LWE2OWYtMTUzY2U4ZWE3OWY0
        //token=dd7b947d5e914316bea11bb6862d1e47
        //These values should be taken from the sdk properties file (downloaded from the admin web-portal under: "INTEGRATE WITH PINGID SDK")
        public static readonly string url = "https://sdk.pingid.com/pingid";

        //public static readonly string accountId = "3115840a-6cd5-4546-a4c0-c40ddddc0747";
        public static string accountId = "";
        //public static readonly string apiKey = "MDI0OGYxZjQtMmVjZS00NGQ0LWE2OWYtMTUzY2U4ZWE3OWY0";
        public static string apiKey = "";

        //public static readonly string token = "dd7b947d5e914316bea11bb6862d1e47";
        public static string token = "";

        //Take this value from the admin web-portal application list (Applications -> PingID SDK Applications)
        //public static readonly string app_id = "84669c9f-fca9-450b-847c-831fb0957bb7";
        public static string app_id = "";

        //SMS message cannot be empty (when pairing device by SMS)
        //public static readonly string DEFAULT_SMS_PAIRING_MESSAGE = "Your PingID SDK pairing code is: ${otp}";
        public static string DEFAULT_SMS_PAIRING_MESSAGE = "Customizable Pairing Message PingID SDK pairing code is: ${otp}";
        //SMS message cannot be empty if the authenticating device is SMS
        public static string DEFAULT_SMS_AUTHENTICATION_MESSAGE = "Customized Authentication PingID SDK authentication code is: ${otp}";
        // Voice message
        public static string DEFAULT_VOICE_PAIRING_MESSAGE = "Your PingID SDK pairing code is ${otp} <repeatMessage val=1> Your Code is ${otp} </repeatMessage>";
        public static string DEFAULT_VOICE_AUTHENICATION_MESSAGE = "Hello your Custom PingID SDK Authentication Code is ${otp}";

        //The name of sms sender (alphanumeric). **Pay Attention!** in the US, for example - you cannot use an alphanumeric sender.
        //In India, only pre-registered alpha-numeric senders can be used. In these cases, the sender field should be left empty.
        //public static readonly string DEFAULT_SENDER_NAME = "Ping";
        public static readonly string DEFAULT_SENDER_NAME = "";

        // created pairing id

        public static string CreatedPairingID = "";

        //email defaults
        public static string EmailFromAddress = "";

        public static string PairingEmailSubject = "";

        public static string AuthEmailSubject = "";

        public static string APIText = "";

        public static string PairCode = "";

        public static string Responsedata = "";

        public static bool autopair = false;







    }
}