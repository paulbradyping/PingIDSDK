﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace PingIDSDK
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

       
        protected void BtnFunctions_Click(object sender, EventArgs e)
        {
            Response.Redirect("SDK-Authenticate.aspx");
            
        }

        protected void BtnLoad_Click(object sender, EventArgs e)
        {
            string test = "";

            try
            {
                // BtnLoadProp.Visible = false;

                string PingIDProp = TxbPingID.Text;

                PingIDProp = PingIDProp.Trim();
                
                //accountID
                test = PingIDProp.Substring(PingIDProp.IndexOf("account_id="));

                test = test.Trim();
                test = test.Substring(test.IndexOf("=") + 1);

                PingIdProperties.accountId = test;

                test = "";

                test = PingIDProp.Substring(PingIDProp.IndexOf("api_key="), 56);

                test = test.Trim();
                test = test.Substring(test.IndexOf("=") + 1);

                PingIdProperties.apiKey = test;

                PingIdProperties.app_id = TxbAppID.Text;

                test = "";

                test = PingIDProp.Substring(PingIDProp.IndexOf("token="), 39);

                test = test.Trim();
                test = test.Substring(test.IndexOf("=") + 1);

                PingIdProperties.token = test;

                LblProfileStatus.Text = "You can Start now by Selecting Enroll and Verify or Verify Existing Users";

                // read the file into the text window and populate the properties class

                // Response.Redirect("SDKAuthenticate.aspx");
                
            }
            catch
            {
                LblProfileStatus.Text = "Unable to Parse contents of the PingID SDK Properties file to continue";
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string test = "";

            try
            {
                // BtnLoadProp.Visible = false;

                string PingIDProp = TxbPingID.Text;

                PingIDProp = PingIDProp.Trim();
                
                //accountID
                test = PingIDProp.Substring(PingIDProp.IndexOf("account_id="));

                test = test.Trim();
                test = test.Substring(test.IndexOf("=") + 1);

                PingIdProperties.accountId = test;

                test = "";

                test = PingIDProp.Substring(PingIDProp.IndexOf("api_key="), 56);

                test = test.Trim();
                test = test.Substring(test.IndexOf("=") + 1);

                PingIdProperties.apiKey = test;

                PingIdProperties.app_id = TxbAppID.Text;

                test = "";

                test = PingIDProp.Substring(PingIDProp.IndexOf("token="), 39);

                test = test.Trim();
                test = test.Substring(test.IndexOf("=") + 1);

                PingIdProperties.token = test;

                LblProfileStatus.Text = "You can Start now by Selecting Enroll and Verify or Verify Existing Users";

                // read the file into the text window and populate the properties class

                // Response.Redirect("SDKAuthenticate.aspx");
                BtnSDkAuth.Visible = true;
                
            }
            catch
            {
                LblProfileStatus.Text = "Unable to Parse contents of the PingID SDK Properties file to continue";
            }

        }

        protected void BtnSDkAuth_Click(object sender, EventArgs e)
        {
            string test = "";

            try
            {
                // BtnLoadProp.Visible = false;

                string PingIDProp = TxbPingID.Text;

                PingIDProp = PingIDProp.Trim();
                
                //accountID
                test = PingIDProp.Substring(PingIDProp.IndexOf("account_id="));

                test = test.Trim();
                test = test.Substring(test.IndexOf("=") + 1);

                PingIdProperties.accountId = test;

                test = "";

                test = PingIDProp.Substring(PingIDProp.IndexOf("api_key="), 56);

                test = test.Trim();
                test = test.Substring(test.IndexOf("=") + 1);

                PingIdProperties.apiKey = test;

                PingIdProperties.app_id = TxbAppID.Text;

                test = "";

                test = PingIDProp.Substring(PingIDProp.IndexOf("token="), 39);

                test = test.Trim();
                test = test.Substring(test.IndexOf("=") + 1);

                PingIdProperties.token = test;

                //LblProfileStatus.Text = "You can Start now by Selecting Enroll and Verify or Verify Existing Users";

                // read the file into the text window and populate the properties class

                // Response.Redirect("SDKAuthenticate.aspx");
                BtnSDkAuth.Visible = true;

                Response.Redirect("SDK-Authenticate.aspx");
            }
            catch
            {
                LblProfileStatus.Text = "Unable to Parse contents of the PingID SDK Properties file to continue";
            }
            
        }

        protected void BtnReset_Click(object sender, EventArgs e)
        {
            TxbAppID.Text = "";
            TxbPingID.Text = "";

        }

        protected void BtnAccountExec_Click(object sender, EventArgs e)
        {
            TxbPingID.Text = TxbAccountExecProp.Text;
            TxbAppID.Text = TxbAccountExecAppID.Text;
                        
            BtnSDkAuth_Click(null, null);
            
        }

        protected void TxbAccountExecProp_TextChanged(object sender, EventArgs e)
        {

        }
    }
}