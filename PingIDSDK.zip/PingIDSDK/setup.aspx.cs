﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PingIDSDK.ErrorHandling;
using PingIDSDK.PingIDSDKHelper;
using PingIDSDK.RestApiResources;

namespace PingIDSDK
{
    public partial class setup : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            LblSMSPairMessage.Text = PingIdProperties.DEFAULT_SMS_PAIRING_MESSAGE;
            LblSMSAuthMessage.Text = PingIdProperties.DEFAULT_SMS_AUTHENTICATION_MESSAGE;

            LblVoicePairMessage.Text = PingIdProperties.DEFAULT_VOICE_PAIRING_MESSAGE;
            LblVoiceAuthMessage.Text = PingIdProperties.DEFAULT_VOICE_AUTHENICATION_MESSAGE;




        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected void BtnSetSMSPairMessage_Click(object sender, EventArgs e)
        {
            
            if(TxbSMSPairMessage.Text!="")
            {
                PingIdProperties.DEFAULT_SMS_PAIRING_MESSAGE = TxbSMSPairMessage.Text+": {otp}";
            }
            else
            {
                LblSetupError.Text = "You Must Enter a Value";
            }

        }

        protected void BtnSetAuthMessage_Click(object sender, EventArgs e)
        {
            if(TxbSMSAuthMessage.Text!="")
            {
                PingIdProperties.DEFAULT_SMS_AUTHENTICATION_MESSAGE = TxbSMSAuthMessage.Text + ": {otp}";
            }
            else
            {
                LblSetupError.Text = "You Must Enter Some Text";

            }
        }

        protected void BtnSetVoicePairMessage_Click(object sender, EventArgs e)
        {
            if(TxbVoicePairMessage.Text!="")
            {
                PingIdProperties.DEFAULT_VOICE_PAIRING_MESSAGE = TxbVoicePairMessage.Text + ": {otp}";

            }
            else
            {
                LblSetupError.Text = "You Must Enter a Value";
            }

        }

        protected void LblSetVoiceAuthMessage_Click(object sender, EventArgs e)
        {
            if(TxbVoiceAuthMessage.Text!="")
            {
                PingIdProperties.DEFAULT_VOICE_AUTHENICATION_MESSAGE = TxbVoiceAuthMessage.Text + ": {otp}";
            }
            else
            {
                LblSetupError.Text = "You Must Enter a Value";
            }
        }

        protected void BtnGetEmailTemplate_Click(object sender, EventArgs e)
        {
            LblSetupError.Text = "Retrieving all email configurations...";
            List<EmailConfiguration> emailConfigurations;
            try
            {
                emailConfigurations = CommonRequests.GetEmailConfigurations();

                for (int x = 0; x < emailConfigurations.Count; x++)
                {
                    LstEmailTemplates.Items.Add(emailConfigurations[x].ToString());

                }

            }
            catch (PingIDSdkException ex)
            {
                LblSetupError.Text = "Failed to retrieving email configurations. details: {0} " + ex;

            }
        }

     

        protected void btnCreateEmailTemplate_Click(object sender, EventArgs e)
        {
            CommonRequests.CreateAuthEmailConfiguration();
            CommonRequests.CreateAuthFromMobileEmailConfiguration();
            CommonRequests.CreatePairingEmailConfiguration();


        }
    }
}